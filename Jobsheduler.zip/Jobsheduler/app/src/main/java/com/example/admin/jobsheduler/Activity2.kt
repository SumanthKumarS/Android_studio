package com.example.admin.jobsheduler

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.ViewParent
import android.widget.*

class Activity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)
        val selectjb = resources.getStringArray(R.array.SelectJB)
        val spinner = findViewById<Spinner>(R.id.spinner)
        val txtview = findViewById<TextView>(R.id.txt2)
        val datetxt = findViewById<EditText>(R.id.sdate)
        val timetxt = findViewById<EditText>(R.id.stime)
        val btnshdule = findViewById<Button>(R.id.b2)
        if (spinner != null){
            val adapterView = ArrayAdapter(this,android.R.layout.simple_spinner_item,selectjb)
            spinner.adapter = adapterView
            spinner.onItemSelectedListener = object :
                    AdapterView.OnItemSelectedListener{
                override fun onNothingSelected(p0: AdapterView<*>?) {
                    TODO("Not yet implemented")
                }

                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long){
                    Toast.makeText(this@Activity2,
                            getString(R.string.selected_item) + " " +
                                    "" + selectjb[position], Toast.LENGTH_SHORT).show()

                }

            }
        }
        btnshdule.setOnClickListener {


        }



    }
}