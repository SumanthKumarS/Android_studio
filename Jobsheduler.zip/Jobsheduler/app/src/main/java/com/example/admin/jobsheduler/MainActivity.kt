package com.example.admin.jobsheduler

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val txtview = findViewById<TextView>(R.id.txtv)

        val btnshdule = findViewById<Button>(R.id.b1)

        btnshdule.setOnClickListener{
            val intent = Intent(this,Activity2::class.java)
            startActivity(intent)
        }

    }
}

