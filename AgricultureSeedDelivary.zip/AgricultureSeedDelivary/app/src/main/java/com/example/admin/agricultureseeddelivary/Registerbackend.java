package com.example.admin.agricultureseeddelivary;

import android.widget.Toast;

public class Registerbackend {
    private String Name;
    private String Email;
    private Long Phone;
    private String Pass;
    private String CPass;
    private String pwd;

    public Registerbackend(){

    }

    public String getName(){
        return Name;
    }

    public void setName(String name){
        Name = name;
    }
    public String getEmail() {return Email;}

    public void setEmail(String email) {Email = email;}
    public Long getPhone(){
        return Phone;
    }

    public void setPhone(Long phone){
        this.Phone = phone;
    }
    public String getPass(){
        return Pass;

    }
    public String getCPass(){
        return CPass;
    }
    public void setPass(String pass){
        Pass = pass;

    }
}
