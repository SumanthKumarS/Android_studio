package com.example.admin.agricultureseeddelivary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import android.util.Patterns;

public class MainActivity2 extends AppCompatActivity {
    EditText name,email,phone,pass,cpass;
    Button reg,bck;
    TextView txt_reg;
    DatabaseReference dbref;
    Registerbackend registerbackend;
    long maxid = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        txt_reg = (TextView) findViewById(R.id.txt);
        name = (EditText)findViewById(R.id.txt_name);
        email = (EditText)findViewById(R.id.txt_email);
        phone = (EditText)findViewById(R.id.txt_phone);
        pass = (EditText)findViewById(R.id.txt_pass);
        cpass = (EditText)findViewById(R.id.txt_copass);
        reg = (Button) findViewById(R.id.reg_btn);
        bck = (Button)findViewById(R.id.bck_btn);
        registerbackend = new Registerbackend();
        dbref = FirebaseDatabase.getInstance().getReference().child("registerbackend");
        dbref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if(snapshot.exists()){
                    maxid=(snapshot.getChildrenCount());
                    //snapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        reg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ValidatePassword();
            }
        });

        bck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity2.this,MainActivity.class);
                startActivity(intent);
            }
        });


    }
    private void ValidatePassword(){
        String nameInput = name.getText().toString().trim();
        String passwordInput = pass.getText().toString().trim();
        String ConfitmpasswordInput = cpass.getText().toString().trim();
        String emailInput = email.getText().toString().trim();
        Long Ph = Long.parseLong(phone.getText().toString().trim());
        System.out.println(passwordInput);
        if (nameInput.equals(null)&&emailInput.equals(null)&&passwordInput.equals(null)&&ConfitmpasswordInput.equals(null)) {
            Toast.makeText(MainActivity2.this,"Password cannot be empty",Toast.LENGTH_LONG).show();
        }
        if ((!passwordInput.equals(ConfitmpasswordInput))) {
            Toast.makeText(MainActivity2.this,"Password Dosent match",Toast.LENGTH_LONG).show();
        }else {
            Toast.makeText(MainActivity2.this,"Password match",Toast.LENGTH_LONG).show();
            registerbackend.setName(nameInput);
            registerbackend.setEmail(emailInput);
            registerbackend.setPhone(Ph);
            registerbackend.setPass(passwordInput);
            //dbref.push().setValue(registerbackend);
            dbref.child(String.valueOf(maxid+1)).setValue(registerbackend);
            Toast.makeText(MainActivity2.this,"data successfully inserted",Toast.LENGTH_LONG).show();
        }
    }



}