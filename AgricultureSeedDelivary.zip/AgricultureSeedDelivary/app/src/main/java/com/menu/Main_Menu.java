package com.menu;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.admin.agricultureseeddelivary.R;

public class Main_Menu extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main__menu);
    }
}