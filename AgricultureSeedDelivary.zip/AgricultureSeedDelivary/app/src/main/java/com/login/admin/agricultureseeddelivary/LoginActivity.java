package com.login.admin.agricultureseeddelivary;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.example.admin.agricultureseeddelivary.MainActivity;
import com.example.admin.agricultureseeddelivary.MainActivity2;
import com.example.admin.agricultureseeddelivary.R;
import com.example.admin.agricultureseeddelivary.Registerbackend;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.menu.Main_Menu;

public class LoginActivity extends AppCompatActivity {
    EditText username,password;
    Button login_btn;
    TextView backsignin;
    DatabaseReference dbref;
    Registerbackend loginbackend;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = (EditText)findViewById(R.id.uname);
        password = (EditText)findViewById(R.id.upass);
        login_btn = (Button)findViewById(R.id.lgbtn);
        backsignin = (TextView)findViewById(R.id.tsig);

        login_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dbref = FirebaseDatabase.getInstance().getReference().child("registerbackend").child("1");
                dbref.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        String uname = snapshot.child("email").getValue().toString();
                        String upass = snapshot.child("pass").getValue().toString();

                        String emailInput = username.getText().toString().trim();
                        String passwordInput = password.getText().toString().trim();
                        if ((!emailInput.isEmpty()) && (!passwordInput.isEmpty()) && emailInput.equals(uname) && passwordInput.equals(upass)){
                            Toast.makeText(LoginActivity.this,"data fetched successfully ",Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(LoginActivity.this, Main_Menu.class);
                            startActivity(intent);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }
        });
        backsignin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, MainActivity2.class);
                startActivity(intent);
            }
        });

    }
}