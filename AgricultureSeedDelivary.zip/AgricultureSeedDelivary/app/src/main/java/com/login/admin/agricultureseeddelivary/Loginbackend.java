package com.login.admin.agricultureseeddelivary;

public class Loginbackend {
    String Email;
    String Pass;
    public Loginbackend(){

    }
    public void setEmail(String email) {Email = email;}
    public void setPass(String pass) {Pass = pass;}
}
