package com.example.register.agricultureseeddelivarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.agricultureseeddelivarysystem.MainActivity;
import com.example.admin.agricultureseeddelivarysystem.R;
import com.example.login.agricultureseeddelivarysystem.Login;
import com.google.firebase.auth.FirebaseAuth;

public class Register extends AppCompatActivity {
    Button lgbtn,regbtn,regsignup;
    EditText registername,registeremail,registerphone,registerpassword,registercpass;
    FirebaseAuth

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        lgbtn = (Button)findViewById(R.id.btnlg);
        regbtn = (Button)findViewById(R.id.btnreg);
        registername = (EditText)findViewById(R.id.ename);
        registeremail = (EditText)findViewById(R.id.eemail);
        registerphone = (EditText)findViewById(R.id.ephone);
        registerpassword = (EditText)findViewById(R.id.epass);
        registercpass = (EditText)findViewById(R.id.ecpass);
        regsignup = (Button)findViewById(R.id.btnsignup);
        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, Register.class);
                startActivity(intent);
            }
        });
        lgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Register.this, Login.class);
                startActivity(intent);
            }
        });
        regsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //extracting the data from the user input
                String uname = registername.getText().toString();
                String uemail = registeremail.getText().toString();
                String uphone = registerphone.getText().toString();
                String upass = registerpassword.getText().toString();
                String ucpass = registercpass.getText().toString();

                if(uname.isEmpty()){
                    registername.setError("Username is Required");
                    return;
                }

                if(uemail.isEmpty()){
                    registeremail.setError("Email is Required");
                    return;
                }
                if(uphone.isEmpty()){
                    registerphone.setError("Phone number is Required");
                    return;
                }
                if(upass.isEmpty() && ucpass.isEmpty()){
                    registerpassword.setError("Password is Required");
                    return;
                }
                if(upass.equals(ucpass)){
                    registercpass.setError("the confirm password dosn't match");
                }
                Toast.makeText(Register.this, "the data entered is valid", Toast.LENGTH_SHORT).show();


            }
        });
    }
}