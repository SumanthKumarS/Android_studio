package com.example.login.agricultureseeddelivarysystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.admin.agricultureseeddelivarysystem.MainActivity;
import com.example.admin.agricultureseeddelivarysystem.R;
import com.example.register.agricultureseeddelivarysystem.Register;

public class Login extends AppCompatActivity {
    Button lgbtn,regbtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        lgbtn = (Button)findViewById(R.id.btnlg);
        regbtn = (Button)findViewById(R.id.btnreg);
        regbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Register.class);
                startActivity(intent);
            }
        });
        lgbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Login.this, Login.class);
                startActivity(intent);
            }
        });
    }
}